export class ShopDevicePageObjects {
    get shopButton() { return $$("table.th-gr-tab a span b") }
}