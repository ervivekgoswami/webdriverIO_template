export const UserData = {

    USERS: {
        TEST_TEAM: {
            userName: "Testing_Team",
            password: "Tmobile#123"
        }

    }

}